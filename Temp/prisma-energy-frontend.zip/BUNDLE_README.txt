PRISMA Campus Energy MILP — Frontend Source Bundle
====================================================

Generated at: 2026-09-18T17:14:30Z
Files: 24

This archive contains the React + TypeScript frontend for the
Campus Microgrid MILP Optimization console.

Run locally:
  cd frontend
  npm install
  npm run dev

The dev server proxies /api/* to http://127.0.0.1:8000 by default.
